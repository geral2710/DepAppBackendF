package com.example.ApiG25;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiG25Application {

	public static void main(String[] args) {
		SpringApplication.run(ApiG25Application.class, args);
	}

}
