package com.example.ApiG25;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiG25ApplicationTests {

	@Test
	void contextLoads() {
	}

}
